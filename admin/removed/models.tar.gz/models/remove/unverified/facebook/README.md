
https://github.com/facebookresearch/fairseq/blob/nllb/examples/nllb/evaluation/README.md